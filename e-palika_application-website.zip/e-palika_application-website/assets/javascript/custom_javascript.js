AOS.init();



// start top scroll button 
const myButton = document.getElementById("scrollToTopBtn");

// Show the button when the user scrolls down 100px from the top of the document
window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        myButton.style.display = "block";
    } else {
        myButton.style.display = "none";
    }
};

// Scroll to the top of the document when the user clicks the button
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
// end top scroll button 